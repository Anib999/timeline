
(function () {
    'use strict';
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });


    // Attendance direct Check In/out from requested date




    $('#sendcheckIn').on('submit', function (e) {
        e.preventDefault();

        var input_val = $('#checkIndatepicker').val().split('-');
        var addZero = function(d){
            if(d < 10)
                return '0'+d;
            return d;
        };
        input_val = input_val[0]+'-'+addZero(input_val[1])+'-'+addZero(input_val[2]);

        var msg_container = $('#checkin_sucess_message');
            var calendar_val = $('#'+input_val).val();
            if (calendar_val.trim() == '' || calendar_val.trim() == 'H') {

                var response = $.ajax({
                    url: $(this).attr('action'),
                    method: 'post',
                    data: $(this).serialize()

                });
                response.done(function (res) {

                    msg_container.text(res.message).show();
                    $('#' + input_val).val(0).css('color', 'green');
                    setTimeout(function () {
                        msg_container.fadeOut();
                    }, 2000);
                });

                response.fail(function (res) {
                    var msg_container = $('#checkin_sucess_message');
                    msg_container.text(res.error).css('color', 'red').show();
                    setTimeout(function () {
                        msg_container.fadeOut();
                    }, 2000);
                });
            } else if(calendar_val.trim() == 'L'){
                msg_container.text('This day is Your Leave day').css('color', 'red').show();
                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            }/*else if(calendar_val.trim() == 'H'){
                msg_container.text('This day is Your Holiday').css('color', 'red').show();
                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            }*/else{
                msg_container.text('You had already checked in on this date').css('color', 'red').show();
                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            }

    });

// Attendance Approve Check In/out from requested user


//    $('#requestCinCoutPost').on('submit', function (e) {
//        e.preventDefault();
//
//        var response = $.ajax({
//            url: $(this).attr('action'),
//            method: 'post',
//            data: $(this).serialize()
//
//        });
//        response.done(function (res) {
//            var msg_container = $('#cInOutmessage');
//            msg_container.text(res.message).show();
//            $('#checkInOut-' + res.date).html('Approved').css('color', 'white').css('background', 'blue');
//            setTimeout(function () {
//                msg_container.fadeOut();
//            }, 2000);
//        });
//
//        response.fail(function (res) {
//            var msg_container = $('#cInOutmessage');
//            msg_container.text(res.error).css('color', 'red').show();
//            setTimeout(function () {
//                msg_container.fadeOut();
//            }, 2000);
//        });
//
//    });




    // Attendance Rejected Check In/out from requested user
//
//
//    $('#checkInOutReject').on('submit', function (e) {
//        e.preventDefault();
//
//        var response = $.ajax({
//            url: $(this).attr('action'),
//            method: 'post',
//            data: $(this).serialize()
//
//        });
//        response.done(function (res) {
//            var msg_container = $('#rejectMessage');
//            msg_container.text(res.message).show();
//            $('#checkInOut-' + res.date).html('Rejected').css('color', 'red').removeAttr('data-toggle data-target');
//            setTimeout(function () {
//                msg_container.fadeOut();
//            }, 2000);
//        });
//
//        response.fail(function (res) {
//            var msg_container = $('#cInOutmessage');
//            msg_container.text(res.error).css('color', 'red').show();
//            setTimeout(function () {
//                msg_container.fadeOut();
//            }, 2000);
//        });
//
//    });
//



    // Attendance Check In

    $('#check_in').on('change', function (e) {
        e.preventDefault();

        var checkbox = $(this);
        var status = checkbox.prop('checked');

        var form = $('#checkIn');
        if (status) {
            var response = $.ajax({
                url: form.attr('action'),
                method: 'post',
                data: form.serialize()

            });

            response.done(function (res) {
                var msg_container = $('#message');
                msg_container.text(res.message).show();
                $('#' + res.date).val(0).css('color', 'green');

                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            });

            response.fail(function (res) {
                var msg_container = $('#message');
                msg_container.text(res.error).css('color', 'red').show();
                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            });
        }

    });



    // Attendance Check Out

    $('#check_out').on('change', function (e) {
        e.preventDefault();

        var checkbox = $(this);

        var status = checkbox.prop('checked');

        var form = $('#checkOut');
        if (status) {
            var response = $.ajax({
                url: form.attr('action'),
                method: 'post',
                data: form.serialize(),

            });

            response.done(function (res) {
                var msg_container = $('#message');
                msg_container.text(res.message).show();

                setTimeout(function () {
                    msg_container.fadeOut();
                }, 2000);
            });

            response.fail(function (res) {

                alert('Something went wrong!! Please try again later...');
            });
        }


    });



    /* 
     * user check In/out request send *
     */

    var check_in = $('.check_in_request');
    var check_out = $('.check_out_request');
    check_in.hide();
    check_out.hide();
    $('#request_type').change(function () {

        var request_type_val = parseInt($(this).val());
        if (request_type_val == 0) {

            check_in.show();
            $('#requestCheckIn').attr('required', 'required');
            check_out.hide();
            $('#requestCheckOut').removeAttr('required');

        } else if (request_type_val == 1) {
            $('#requestCheckOut').attr('required', 'required');
            check_out.show();
            check_in.hide();
            $('#requestCheckIn').removeAttr('required');
        } else if (request_type_val == 2) {
            $('#requestCheckIn').attr('required', 'required');
            $('#requestCheckOut').attr('required', 'required');
            check_in.show();
            check_out.show();
        } else {
            check_in.hide();
            check_out.hide();
        }
    });


// On submit check in/out request

    $('#checkInRequest').on('submit', function (e) {
        e.preventDefault();

        var response = $.ajax({
            url: $(this).attr('action'),
            method: 'post',
            data: $(this).serialize()

        });

        response.done(function (res) {
            var msg_container = $('#message');
            msg_container.text(res.message).show();

            setTimeout(function () {
                msg_container.fadeOut();
            }, 2000);
        });

        response.fail(function (res) {

            alert('Something went wrong!! Please try again later...');
        });

    });




    // make message to read message


    $('#messages').on('click', '.message', function (e) {
        e.preventDefault();

        var notification = $('#notification_count');
        var notification_count_val = parseInt(notification.text()) - 1;



        var response = $.ajax({
            url: $(this).attr('action'),
            method: $(this).attr('method'),
            data: $(this).serialize
        });

        response.done(function (res) {

            notification.text(notification_count_val);

            setTimeout(function () {
                $('#message-' + res.id).fadeOut();
            }, 500);
        });

        response.fail(function (res) {

            $('#message-' + res.id).html('error').css('color', 'red');
        });

    });

})();