<?php
$g_translations = array (
		"fr_fr" => array (
			"Source String" => "Translation"
			),
		"fr_fr" => array (
			"Source String" => "Translation"
			),
		);

$g_report_desc = array ( 
        "fr_fr" => array (
		"reportdefinition.xml" => 
        "Translated description"
			)
		);
?>
