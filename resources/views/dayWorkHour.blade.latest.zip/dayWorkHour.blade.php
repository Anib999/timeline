@extends('layouts.app')
@section('head')
<link rel="stylesheet" href="{{asset('css/jquery-ui.min.css')}}">
@stop

@section('footer')
<script type="text/javascript" src="{{ asset('js/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/date.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/scripts.js') }}"></script>

<script>
    $(function () {
    $("#fromDate").datepicker();
    });
    $(function () {
    $("#toDate").datepicker();
    });</script>
@stop
@section('content')

<div class="container">
    <div class="row">
        @include('partials.dayHourReport')
        <div class="col-md-5">
            <div class="panel panel-default">
                <div class="panel-body">
                    @if (Session::has('message'))
                    <div class="alert alert-success text-center">{{ Session::get('message') }}</div>
                    @endif
                    <form action="{{route('dayWorkHour.store')}}" method="POST" class="form-horizontal" id="dayWorkHour">
                        {{csrf_field()}}

                        <div id="project-dropdown-container">
                            <div class="form-group{{ $errors->has('project_id') ? ' has-error' : '' }} ">
                                <label class="col-md-4" >Project</label>
                                <div class="col-md-8">
                                    <select class="form-control" name="project_id" id="project" data-url="{{ url('api/projectdropdown')}}" required="required">
                                        <option> </option>
                                        @foreach($projects as $project)
                                        <option value="{{ $project->id }}">{{ $project->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('project_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('project_id') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group{{ $errors->has('subcat_id') ? ' has-error' : '' }}">
                                <label class="col-md-4">SubCategory </label>
                                <div class="col-md-8">
                                    <select class="form-control" name="subcat_id" id="sub_category" data-url="{{ url('api/subcatdropdown')}}" required="required">
                                        <option value=""></option>
                                    </select>
                                    @if ($errors->has('subcat_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('subcat_id') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <!-- <div class="form-group{{ $errors->has('job_id') ? ' has-error' : '' }}">
                                <label class="col-md-4">Job </label>
                                <div class="col-md-8">
                                    <select class="form-control" name="job_id" id="job_input"   onchange="document.getElementById('displayValue').value = this.options[this.selectedIndex].text;" required="required">
                                        <option value=""></option>
                                       
                                    </select>
                                    @if ($errors->has('job_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('job_id') }}</strong>
                                    </span>
                                    @endif
                                    <input type="button" value=" Select/Create Job" class="btn btn-default pull-right" id="displayValue" data-toggle="modal" data-target="#modal-project-job"  style="position:absolute;top:2px; margin-left:2px;border:  none; padding: 2%; height: 33px; width: 80%;" />
                                </div>
                            </div> -->
                        </div>
                        <div class="form-group{{ $errors->has('workDetail') ? ' has-error' : '' }}">
                            <label  for="workDetail" class="col-md-4">Work Detail</label>
                            <div class="col-md-8">
                                <select route="{{route('workDetailsAPI')}}" class="form-control" id="workDetail" name="workDetail" required >
                                    <option value=""> </option>
                                </select>
                                @if ($errors->has('workDetail'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('workDetail') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>

                        <!-- <div id="dayWorkHourdetail"> -->
                            <div class="form-group{{ $errors->has('dayWorkdHour') ? ' has-error' : '' }}">
                                <label for="dayWorkdHour" class="col-md-4">Work Hour</label>
                                <div class="col-md-8">
                                    
                                    <input type="number" step="0.25" class="form-control" id="dayWorkdHour" placeholder="Work Hour"value="{{ old('dayWorkHour') }}" name="dayWorkdHour" required>
                                    @if ($errors->has('dayWorkdHour'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('dayWorkdHour') }}</strong>
                                    </span>
                                    @endif
                                    
                                </div>
                            </div>

                            <div class="form-group {{ $errors->has('workComment') ? ' has-error' : '' }}">
                                <label for="workComment" class="col-md-4">Comments</label>
                                <div class="col-md-8">
                                    
                                    <textarea class="form-control" name="workComment" id="workComment"  placeholder="Add Description" > {{ old('workComment') }} </textarea>
                                    @if ($errors->has('workComment'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('workComment') }}</strong>
                                    </span>
                                    @endif
                                    
                                </div>
                            </div>                            
                        <!-- </div> -->

                        <div class="form-group">
                            <div class="col-md-3 pull-right text-right">
                                <button class="btn btn-success" type="button" id="add-job" style="padding-left:32px;padding-right:32px;">Add</button>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

(function(){
    function HtmlEncode(s){
        var el = document.createElement("div");
        el.innerText = el.textContent = s;
        s = el.innerHTML;
        return s;
    }

    $('#add-job').on('click',function(){
        var project = parseInt($('#project').val());
        var subCategory = parseInt($('#sub_category').val());
        var workDetail = parseInt($('#workDetail').val());
        var workComment = HtmlEncode($('#workComment').val().trim());
        var workHour = parseFloat($('#dayWorkdHour').val());

        if( isNaN(project) || isNaN(subCategory) || isNaN(workDetail) || workComment == '' || isNaN(workHour)){
            if(workHour < 0){
                alert('Work Hour cannot be in negative.');
                return;
            }
            alert( 'These feild/s are empty: \n'+
                ((isNaN(project))?'Project\n':'')+
                ((isNaN(subCategory))?'Sub Category\n':'')+
                ((isNaN(workDetail))?'Work Detail\n':'')+
                ((workComment == '')?'Comment\n':'')+
                ((isNaN(workHour))?'Work Hour':'') );
            return;
        }

        var projectDetailsContainer = $('#projectDetailsContainer-table');
        var last_workDetailRow_ID =  projectDetailsContainer.find('tbody.projectDetailsContainer-fields-container tr:last-child').attr('id');
        if(last_workDetailRow_ID == undefined)
            last_workDetailRow_ID = 'workDetail_row__1';
        else
            last_workDetailRow_ID = 'workDetail_row__' + (parseInt(last_workDetailRow_ID.split('__')[1]) + 1);

        projectDetailsContainer.find('tbody.projectDetailsContainer-fields-container').append(
            '<tr id="'+ last_workDetailRow_ID +'">'+
            '<td><span class="delete-row text-danger">&times;</span></td>'+
            '<td class="project-field" project="'+ project +'">'+ $('#project :selected').text() +'</td>'+
            '<td class="subCategory-field" subCategory="'+ subCategory +'">'+ $('#sub_category :selected').text() +'</td>'+
            '<td class="workDetail-field" workDetail="'+ workDetail +'">'+ $('#workDetail :selected').text() +'</td>'+
            '<td class="workHour-field">'+ workHour +'</td>'+
            '<td class="workComment-field">'+ workComment +'</td>'+
            '</tr>'
        );

        //var projectDetailsGroupContainer = $('#projectDetailsGroupContainer-'+project);

        var totalHours = projectDetailsContainer.find('tbody.totalHours-container .totalHours-field');
        totalHours.text( parseFloat( totalHours.text() )+ workHour );
        $('#dayWorkHour')[0].reset();

        $('.submitWorkDay').show();
    });

    $('#dayWorkHour').on('submit',function(e){
        e.preventDefault();
    });

    $('#WorkDayDetails').on('submit',function(e){
        e.preventDefault();
        $('body,html').animate({scrollTop: 0});
        
        var data = {
            'workDayDetails':{},
            '_token': $('meta[name="csrf-token"]').attr('content'),
            'totalWorkHour': parseFloat($('#projectDetailsContainer-table tbody.totalHours-container .totalHours-field').text())
            };
        var workDayDetails_row = $('#projectDetailsContainer-table tbody.projectDetailsContainer-fields-container tr');
        
        if(workDayDetails_row.length == 0){
            alert('Please add your work day detail/s.');
            return;
        }

        var workDetail_data = [];
        $.each(workDayDetails_row,function(){
            let workDetail_row = $(this);
            let data_row = [];
            let project = workDetail_row.find('.project-field');
            let subcategory = workDetail_row.find('.subCategory-field');
            let workDetail = workDetail_row.find('.workDetail-field');
            data_row.push({'project': project.attr('project'),
                            'project_name': project.text(),
                            'subCategory': subcategory.attr('subCategory'),
                            'subCategory_name': subcategory.text(),
                            'workDetail': workDetail.attr('workDetail'),
                            'workDetail_name': workDetail.text(),
                            'workComment':workDetail_row.find('.workComment-field').text(),
                            'workHour':workDetail_row.find('.workHour-field').text(),
                            'workDetail_row': workDetail_row.attr('id')
                            });

            workDetail_data.push(data_row);
        });


        data['workDayDetails'] = workDetail_data;
        console.log( data );

        var submitWorkDetails = $.ajax({
            url: $('#dayWorkHour').attr('action'),
            method: 'post',
            data: data,
            dataType: 'json'
        });

        $('#submitting-status').height( $('#WorkDayDetails').height() ).width( $('#WorkDayDetails').width() ).show();

        submitWorkDetails.done(function(res){
            //console.log( res );
            var inserted_row = res.inserted;
            var alreadyExist = res.alreadyExists;

            for(let i = 0; i < alreadyExist.length; i++){
                $('#'+alreadyExist[i])
                .addClass('warning')
                .after('<tr class="text-center info status"><td colspan="6"><small style="font-weight:bold;">You have already submitted this work detail</small></td></tr>');
            }

            let inserted_row_IDs = Object.keys(inserted_row);
            for(let i = 0; i < inserted_row_IDs.length; i++){
                let row_delete_icon = $('#'+inserted_row_IDs[i]).find('span.delete-row');
                row_delete_icon.removeClass('delete-row');
                row_delete_icon.addClass('deleteTodaysWorkEntry-row');
                row_delete_icon.attr('entryid',inserted_row[inserted_row_IDs[i]]);

                $('#'+inserted_row_IDs[i]).addClass('success');

                var workDayDetailsTableBody = '#projectDetailsContainer-table tbody.todaysWorkEntriesContainer';
                $('#'+inserted_row_IDs[i]).clone().removeAttr('id').appendTo(workDayDetailsTableBody);

                $('#'+inserted_row_IDs[i]).remove();
            }
            
            $('#submitting-status').hide();
        });

        submitWorkDetails.fail(function(res){
            console.log( res );
            alert('Something went wrong with the server. Please contact your administrator.');
            $('#submitting-status').hide();
        });
        
    });

    $('#projectDetailsContainer-table').on('click','.delete-row',function(){
        var table_row = $(this).parents('tr');
        var workHour = parseFloat(table_row.find('.workHour-field').text());

        var totalHours = $('#projectDetailsContainer-table tbody.totalHours-container .totalHours-field');
        totalHours.text( parseFloat( totalHours.text() ) - workHour );
        
        var next_row = table_row.next('tr.status');
        var next_row_prev_row = next_row.prev('tr');
        if(next_row_prev_row.attr('id') == table_row.attr('id'))
            next_row.remove();

        table_row.remove();

        if( $('#projectDetailsContainer-table tbody.projectDetailsContainer-fields-container tr').length == 0 )
            $('#WorkDayDetails button[type="submit"]').hide();
        
    });

    $('#projectDetailsContainer-table').on('click','.deleteTodaysWorkEntry-row',function(e){
        if(!confirm('Are you sure want to delete your work entry ?'))
            return;
        
        var delete_span = $(this);
        var data = {
            'workDetailId': delete_span.attr('entryid'),
            '_token': $('meta[name="csrf-token"]').attr('content'),
        }
        var delete_selected_row = delete_span.parents('tr');
        var workHour = parseFloat(delete_selected_row.find('td.workHour-field').text());

        var deleteTodayWorkEntryStatus = $.ajax({
            url: $('#deleteWorkEntryAPI').val(),
            method: 'post',
            data: data,
            dataType: 'json'
        });
        delete_span.hide();
        delete_span.after('<i class="wait_ fa fa-spinner fa-spin"></i>');

        deleteTodayWorkEntryStatus.done(function(res){
            //console.log( res );
            if(res.delete == true){
                delete_selected_row.fadeOut(1000,function(){
                    $(this).remove();
                });
                var totalHours = $('#projectDetailsContainer-table tbody.totalHours-container .totalHours-field');
                totalHours.text( parseFloat( totalHours.text() ) - workHour );
            }else{
                alert('Ooops! Could not delete your work entry at the moment, Please try again later.');
                delete_span.siblings().remove();
                delete_span.show();
            }
        });

        deleteTodayWorkEntryStatus.fail(function(res){
            console.log( res );
            alert('Ooops! Something went wrong with the server, Please try again later.');
            delete_span.siblings().remove();
            delete_span.show();
        });

    });

})();

</script>

@endsection