@extends('layouts.app')
@section('head')
<link rel="stylesheet" href="{{asset('css/jquery-ui.min.css')}}">
@stop

@section('footer')
<script type="text/javascript" src="{{ asset('js/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/date.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/scripts.js') }}"></script>

<script>
    $(function () {
    $("#fromDate").datepicker();
    });
    $(function () {
    $("#toDate").datepicker();
    });</script>
@stop
@section('content')

<div class="container">
    <div class="row">
        @include('partials.dayHourReport')
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    @if (Session::has('message'))
                    <div class="alert alert-success text-center">{{ Session::get('message') }}</div>
                    @endif
                    <form action="{{route('dayWorkHour.store')}}" method="POST" class="form-horizontal" id="dayWorkHour">
                        {{csrf_field()}}

                        <div id="project-dropdown-container">
                            <div class="form-group{{ $errors->has('project_id') ? ' has-error' : '' }} ">
                                <label class="col-md-4" >Project</label>
                                <div class="col-md-8">
                                    <select class="form-control" name="project_id" id="project" data-url="{{ url('api/projectdropdown')}}" required="required">
                                        <option> </option>
                                        @foreach($projects as $project)
                                        <option value="{{ $project->id }}">{{ $project->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('project_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('project_id') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group{{ $errors->has('subcat_id') ? ' has-error' : '' }}">
                                <label class="col-md-4">SubCategory </label>
                                <div class="col-md-8">
                                    <select class="form-control" name="subcat_id" id="sub_category" data-url="{{ url('api/subcatdropdown')}}" required="required">
                                        <option value=""></option>
                                    </select>
                                    @if ($errors->has('subcat_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('subcat_id') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <!-- <div class="form-group{{ $errors->has('job_id') ? ' has-error' : '' }}">
                                <label class="col-md-4">Job </label>
                                <div class="col-md-8">
                                    <select class="form-control" name="job_id" id="job_input"   onchange="document.getElementById('displayValue').value = this.options[this.selectedIndex].text;" required="required">
                                        <option value=""></option>
                                       
                                    </select>
                                    @if ($errors->has('job_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('job_id') }}</strong>
                                    </span>
                                    @endif
                                    <input type="button" value=" Select/Create Job" class="btn btn-default pull-right" id="displayValue" data-toggle="modal" data-target="#modal-project-job"  style="position:absolute;top:2px; margin-left:2px;border:  none; padding: 2%; height: 33px; width: 80%;" />
                                </div>
                            </div> -->
                        </div>
                        <div class="form-group{{ $errors->has('dayWork') ? ' has-error' : '' }}">
                            <label  for="dayWork" class="col-md-4">Work Detail</label>
                            <div class="col-md-8">
                                <select class="form-control" id="dayWork" name="dayWork" required >
                                    <option> </option>
                                    @foreach($workTypes as $workType)
                                    <option value="{{$workType}}"> {{$workType}}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('dayWork'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('dayWork') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>

                        <!-- <div id="dayWorkHourdetail"> -->
                            <div class="form-group{{ $errors->has('dayWorkdHour') ? ' has-error' : '' }}">
                                <label for="dayWorkdHour" class="col-md-4">Work Hour</label>
                                <div class="col-md-8">
                                    
                                    <input type="number" step="0.5" class="form-control" id="dayWorkdHour" placeholder="Work Hour"value="{{ old('dayWorkHour') }}" name="dayWorkdHour" required>
                                    @if ($errors->has('dayWorkdHour'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('dayWorkdHour') }}</strong>
                                    </span>
                                    @endif
                                    
                                </div>
                            </div>

                            <div class="form-group {{ $errors->has('dayWorkdetail') ? ' has-error' : '' }}">
                                <label for="dayWorkdetail" class="col-md-4">Comments</label>
                                <div class="col-md-8">
                                    
                                    <textarea class="form-control" name="dayWorkdetail" id="dayWorkdetail"  placeholder="Add Description" > {{ old('dayWorkdetail') }} </textarea>
                                    @if ($errors->has('dayWorkdetail'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('dayWorkdetail') }}</strong>
                                    </span>
                                    @endif
                                    
                                </div>
                            </div>                            
                        <!-- </div> -->

                        <div class="form-group">
                            <div class="col-md-3 pull-right text-right">
                                <button class="btn btn-success" type="button" id="add-job" style="padding-left:32px;padding-right:32px;">Add</button>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

(function(){
    function HtmlEncode(s){
        var el = document.createElement("div");
        el.innerText = el.textContent = s;
        s = el.innerHTML;
        return s;
    }

    $('#add-job').on('click',function(){
        var project = $('#project').val();
        var subCategory = $('#sub_category').val();
        var workDetail = $('#dayWork').val();
        var workComment = HtmlEncode($('#dayWorkdetail').val().trim());
        var workHour = parseFloat($('#dayWorkdHour').val());

        if( project == '' || subCategory == '' || workDetail == '' || workComment == '' || workHour == NaN){
            alert( 'These feild/s are empty: \n'+
                ((project == '')?'Project\n':'')+
                ((subCategory == '')?'Sub Category\n':'')+
                ((workDetail == '')?'Work Detail\n':'')+
                ((workComment == '')?'Comment\n':'')+
                ((workHour == '')?'Work Hour':'') );
            return;
        }

        var projectContainer = $( '#projectContainer-'+project );
        if( projectContainer.length == 0 ){
            var projectDiv = $('<div>').attr('id','projectContainer-'+project);
            projectDiv.addClass('projectContainer');
            var subCategoryDiv =  $('<div>').attr('id','subCategoryContainer-'+subCategory);
            subCategoryDiv.html('<h5 style="text-transform: capitalize; font-weight:bold;background: #00000024;padding: 6px;">'+$('#sub_category :selected').text()+'</h5><table class="workDetailTable table table-striped">'+
            '<thead>'+
            '<th>Work Details</th>'+
            '<th>Work Hours</th>'+
            '<th>Comments</th>'+
            '</thead>'+
            '<tbody><tr>'+
            '<td class="workDetail-field" workDetail="'+workDetail+'">'+ $('#dayWork :selected').text() +'</td>'+
            '<td class="workHour-field">'+ workHour +'</td>'+
            '<td class="workComment-field">'+ workComment +'</td>'+
            '</tr></tbody>'+
            '</table>'+
            '<table class="totalWorkingHour table table-striped"><th>Total Work Hour</th><td>'+workHour+'</td><td></td></table>'
            );
            
            projectDiv.html( '<h4 class="bg-danger" style="padding:6px;text-transform: capitalize; font-weight:bold;">'+ $('#project :selected').text() +'</h4>' );
            projectDiv.append( subCategoryDiv );


            $('#workDayHourView').append( projectDiv );
        }else{
            var subCategoryContainer = $('#subCategoryContainer-'+subCategory);
            if(subCategoryContainer.length == 0){
                var subCategoryDiv =  $('<div>').attr('id','subCategoryContainer-'+subCategory);
                subCategoryDiv.html('<h5 style="text-transform: capitalize; font-weight:bold;background: #00000024;padding: 6px;">'+$('#sub_category :selected').text()+'</h5><table class="workDetailTable table table-striped">'+
                '<thead>'+
                '<th>Work Details</th>'+
                '<th>Work Hours</th>'+
                '<th>Comments</th>'+
                '</thead>'+
                '<tbody><tr>'+
                '<td class="workDetail-field" workDetail="'+workDetail+'">'+ $('#dayWork :selected').text() +'</td>'+
                '<td class="workHour-field">'+ workHour +'</td>'+
                '<td class="workComment-field">'+ workComment +'</td>'+
                '</tr></tbody>'+
                '</table>'+
                '<table class="totalWorkingHour table table-striped"><th>Total Work Hour</th><td>'+workHour+'</td><td></td></table>');
                
                projectContainer.append( subCategoryDiv );
                
            }else{
                subCategoryContainer.find('table.workDetailTable').append('<tr>'+
                '<td>'+ $('#dayWork :selected').text() +'</td>'+
                '<td>'+ workHour +'</td>'+
                '<td>'+ workComment +'</td></tr>');

                var totalWorkingHourTable = subCategoryContainer.find('table.totalWorkingHour td:eq(0)');

                totalWorkingHourTable.text(parseFloat(totalWorkingHourTable.text()) + workHour);
            }
        }

        $('.submitWorkDay').show();
    });

    $('#dayWorkHour').on('submit',function(e){
        e.preventDefault();
    });

    $('#WorkDayDetails').on('submit',function(e){
        e.preventDefault();
    });
})();

</script>

@endsection